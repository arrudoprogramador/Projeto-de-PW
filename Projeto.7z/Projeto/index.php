<?php
  header("Location: areaUser/home.php");
?>