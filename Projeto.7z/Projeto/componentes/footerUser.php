<footer class="container-fluid footer w-100">
  <a href="#" target="blank" class="me-4">FilmeOn © 2023 </a>
  <a href="#" target="blank" class="me-4">Instagram</a>
  <a href="#" class="me-4">YouTube</a>
  <a href="#" class="me-4">Twitter</a>
  <a href="../areaAdmin/login/login.php" target="blank" class="me-4">admin</a>
</footer>