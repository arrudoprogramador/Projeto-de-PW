<div class="col-md-2  p-4 border" style="background-color:#e0e0e0;">
  <ul class="nav flex-column ">
    <li class="fw-medium my-1">
      <a class="link-dark" href="../home" style="text-decoration: none;"><i class="fas fa-home"></i> Home</a>
    </li>
    <li class="fw-medium my-1">
      <a class="link-dark" href="../adm" style="text-decoration: none;"><i class="fas fa-user-circle"></i> Adm</a>
    </li>
    <li class="fw-medium my-1">
      <a class="link-dark" href="../user" style="text-decoration: none;"><i class="fas fa-user"></i> User</a>
    </li>
    <li class="fw-medium my-1">
      <a class="link-dark" href="../movie" style="text-decoration: none;"><i class="fas fa-film"></i> Filmes</a>
    </li>
    <li class="fw-medium my-1">
      <a class="link-dark" href="../categoria" style="text-decoration: none;"><i class="fas fa-plus-square"></i> Categoria</a>
    </li>
  </ul>
</div>